<div id="before_wrapper">
	<div class="content_widgets">
		<?php dynamic_sidebar( 'content-widget-area' ); ?>
	</div>
</div>