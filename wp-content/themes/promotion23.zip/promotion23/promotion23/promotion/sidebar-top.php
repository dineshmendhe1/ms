<div id="top_sidebar" class="widget-area">
<ul class="xoxo">
<?php dynamic_sidebar( 'top-widget-area' ); ?>
</ul>
</div>
<div class="v_clear"></div>